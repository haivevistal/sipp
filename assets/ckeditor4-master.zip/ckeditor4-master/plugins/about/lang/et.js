/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'about', 'et', {
	copy: 'Copyright &copy; $1. Kõik õigused kaitstud.',
	dlgTitle: 'CKEditor 4st lähemalt',
	moreInfo: 'Litsentsi andmed leiab meie veebilehelt:'
} );
