/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'about', 'de-ch', {
	copy: 'Copyright &copy; $1. Alle Rechte vorbehalten.',
	dlgTitle: 'Über CKEditor 4',
	moreInfo: 'Für Informationen über unsere Lizenzbestimmungen besuchen Sie bitte unsere Webseite:'
} );
