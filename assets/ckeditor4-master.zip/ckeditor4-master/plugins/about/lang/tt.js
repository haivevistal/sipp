/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'about', 'tt', {
	copy: 'Copyright &copy; $1. Бар хокуклар сакланган',
	dlgTitle: 'CKEditor турында',
	moreInfo: 'For licensing information please visit our web site:' // MISSING
} );
