/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'about', 'mk', {
	copy: 'Авторски права &copy; $1. Сите права се задржани.',
	dlgTitle: 'За CKEditor 4',
	moreInfo: 'За информации околу лиценцата, ве молиме посетете го нашиот веб-сајт: '
} );
