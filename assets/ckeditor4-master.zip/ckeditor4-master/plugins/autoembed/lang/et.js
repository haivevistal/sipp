/*
 Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */
CKEDITOR.plugins.setLang( 'autoembed', 'et', {
	embeddingInProgress: 'Püütakse asetatud URLi sisu lisada...',
	embeddingFailed: 'Selle URLi sisu ei saa automaatselt dokumenti lisada.'
} );
