# elfinder-with-codeigniter-3
Clean implementation of elfinder plugin in CodeIgniter 3

### What you need
1. CodeIgniter 3.0
2. [Elfinder] (http://elfinder.org/) plugin

That's all.

### Steps to implement

1. Place the directory structure in your codeigniter setup
2. Check the controller method to implement the helper function.


Ennnnjoy !!  
